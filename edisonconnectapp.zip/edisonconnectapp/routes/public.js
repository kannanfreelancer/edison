const express = require('express');
const router = express.Router();
const auth = require('../controllers/auth');
const forgotPassword = require('../controllers/forgotPassword');
const validate = require('express-validation');
const authValidation = require('../validations/auth')

router.route('/auth/login').post(validate(authValidation.loginParam), auth.login);
router.route('/auth/validateLogin').post(forgotPassword.validateLogin);
router.route('/auth/validatePIN').post(forgotPassword.validatePIN);
router.route('/auth/forgot-password').post(forgotPassword.forgot_password);
router.route('/auth/forgotPassword').post(forgotPassword.forgotPassword);
router.route('/auth/createPin').post(forgotPassword.createPin);
router.route('/auth/getCareGiverDashboard').post(forgotPassword.getCareGiverDashboard);

module.exports = router;