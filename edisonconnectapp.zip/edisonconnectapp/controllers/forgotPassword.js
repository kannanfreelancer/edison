const User = require('../models/auth_user');
const mailer = require('../mailer/mailer');
const async = require('async');
const crypto = require('crypto');
const path = require('path');
const { db_read } = require('../config/db');
const Hash = require('crypto-js/pbkdf2');

exports.forgot_password = function(req, res) {
    async.waterfall([
      function(done) {
        User.findbyEmail({
          email: req.body.email
        },(err, res)=>{
          if (res) {
            done(err, res);
          } else {
            done('User not found.');
          }
        })
      },
      function(user, done) {
        // create the random token
        crypto.randomBytes(20, function(err, buffer) {
          var token = buffer.toString('hex');
          done(err, user, token);
        });
      },
      function(user, token, done) {
        User.findByIdAndUpdate( { id: user.id, reset_password_token: token, reset_password_expires: Date.now() + 86400000 },(err, new_user) => {
          done(err, token, new_user);
        });
      },
      function(token, user, done) {

        var data = {
          to: user.email_id,
          from: 'kumarapkvel@gmail.com',
          template: 'forgot-password-email',
          subject: 'Password help has arrived!',
          context: {
            url: 'http://localhost:3000/auth/reset_password?token=' + token,
            name: user.first_name
          }
        };
        
        smtpTransport.sendMail(data, function(err) {
          console.log('am in ',err)
          if (!err) {
            return res.json({ message: 'Kindly check your email for further instructions' });
          } else {
            return done(err);
          }
        });
      }
    ], function(err) {
      return res.status(422).json({ message: err });
    });
  };

  exports.createPin = function(req, res) {
    const query = "UPDATE `tbl_users` SET `mobile_pin` = '"+req.body.mobile_pin+"' WHERE `id` = "+ req.body.id;

    console.log(query);

    db_read.query(query, (err, response, fields) => {
      console.log(err, response)
      if (!err) {
        return res.status(200).json({ message: 'mPIN created successfully',error:0 });
      } else {
        return res.status(422).json({ message: err,error:1 });
      }
    });
  };

  exports.getCareGiverDashboard = function(req, res) {
    const query = "SELECT patient.id as patient_id,patient.patient_unique_id,patient.priority,disposable.device_type,bed.bed_number,bedtype.bed_type,"+
    "td.transmitter_id,td.wetness_level,td.humididy_level,td.room_temperature,td.fall_detection,td.battery_level,td.temperature_level,td.transmitter_status "+
    "FROM edison_connect_db.tbl_patients as patient LEFT JOIN edison_connect_db.tbl_beds as bed "+
    "ON patient.bed_id = bed.id LEFT JOIN edison_connect_db.tbl_bed_master as bedtype "+
    "ON bedtype.id = bed.bed_type_id LEFT JOIN edison_connect_db.tbl_transmitter as trans "+
    "ON trans.id = patient.transmitter_id LEFT JOIN edison_connect_db.tbl_device_type as disposable "+
    "ON disposable.id = trans.transmitter_type LEFT JOIN edison_connect_db.tbl_transmitter_read_data as td "+
    "ON td.id = trans.id WHERE patient.care_giver_id = "+ req.body.id;

    console.log(query);

    db_read.query(query, (err, response, fields) => {
      console.log(err, response)
      if (!err) {
        return res.status(200).json({ items: response,error:0 });
      } else {
        return res.status(422).json({ message: err,error:1  });
      }
    });
  };

  exports.validatePIN = function(req, res) {

    const query1 = "SELECT * FROM tbl_users where id= "+ req.body.id+" and mobile_pin="+req.body.mobile_pin;

    console.log(query1);

    db_read.query(query1, (err, response, fields) => {
      console.log(err, response);
      if (!err && response.length === 1) {
          const user = response[0];
          const query = "UPDATE `tbl_users` SET `last_login_time` = NOW(),active_status=1 WHERE `id` = "+ req.body.id;

          console.log(query);

          db_read.query(query, (err, response, fields) => {
            console.log(err, response);
            if (!err) {
              return res.status(200).json({ info: user,error:0 });
            } else {
              return res.status(422).json({ message: err,error:1 });
            }
          });
        }else {
          return res.status(400).json({ message: 'Invalid mPIN',error:1  });
        }
      });
  };

  exports.validateLogin = function(req, res) {

    const passwordInput = Hash(req.body.password, config.appSecret).toString();

    console.log(passwordInput);

    const query1 = "SELECT * FROM tbl_users where user_name= '"+ req.body.user_name+"' and password='"+passwordInput+"'";

    console.log(query1);

    db_read.query(query1, (err, response, fields) => {
      console.log(err, response);
      if (!err && response.length === 1) {
          const user = response[0];
          const query = "UPDATE `tbl_users` SET `last_login_time` = NOW(),active_status=1 WHERE `user_name` = '"+ req.body.user_name+"'";

          console.log(query);

          db_read.query(query, (err, response, fields) => {
            console.log(err, response);
            if (!err) {
              return res.status(200).json({ info: user,error:0 });
            } else {
              return res.status(422).json({ message: err,error:1 });
            }
          });
        }else {
          return res.status(401).json({ message: 'Invalid User Name / Password',error:1  });
        }
      });
  };

  exports.forgotPassword = function(req, res) {

    const query1 = "SELECT * FROM tbl_users where email_id= '"+ req.body.email_id+"'";

    console.log(query1);

    db_read.query(query1, (err, response, fields) => {
      console.log(err, response);
      if (!err && response.length === 1) {
          return res.status(200).json({ message: 'Kindly check your email for further instructions',error:0 });
        }else {
          return res.status(200).json({ message: 'Invalid Email ID',error:1  });
        }
      });
  };